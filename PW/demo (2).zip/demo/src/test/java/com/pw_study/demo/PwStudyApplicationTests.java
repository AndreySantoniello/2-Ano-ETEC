package com.pw_study.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
