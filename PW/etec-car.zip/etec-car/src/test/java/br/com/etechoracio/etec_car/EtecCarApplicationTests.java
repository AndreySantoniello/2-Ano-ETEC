package br.com.etechoracio.etec_car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtecCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
