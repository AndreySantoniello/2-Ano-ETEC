package br.com.etechoracio.etec_car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtecCarApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtecCarApplication.class, args);
	}

}
